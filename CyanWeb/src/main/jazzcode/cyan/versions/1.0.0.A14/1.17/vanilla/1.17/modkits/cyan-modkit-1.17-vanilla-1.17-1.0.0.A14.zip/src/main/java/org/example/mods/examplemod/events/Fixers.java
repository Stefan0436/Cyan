package org.example.mods.examplemod.events;

import org.asf.cyan.mods.events.IEventListenerContainer;

public class Fixers implements IEventListenerContainer {

}
