#!/bin/sh
java -jar DigitalRoadmap-1.0.0.A1-all.jar ./roadmap.drf
