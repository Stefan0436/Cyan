forge=
fabric=0.11.6
paper=72

mappings_paper=6fd92758670a4c38ceb1b4dc6ed671547185f414:PB_72
