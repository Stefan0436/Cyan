forge=36.1.32
fabric=0.11.6
paper=778

mappings_paper=f0a5ed1aeff8156ba4afa504e190c838dd1af50c:1_16_R3
